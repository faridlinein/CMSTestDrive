# -*- coding: utf-8 -*-
from django.apps import AppConfig


class AldrynNewsBlog(AppConfig):
    name = 'aldryn_newsblog'
    verbose_name = 'Aldryn News & Blog'
