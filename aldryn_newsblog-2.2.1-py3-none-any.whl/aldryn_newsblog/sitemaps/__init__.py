from .sitemap import NewsBlogSitemap  # NOQA
