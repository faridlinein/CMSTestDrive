# -*- coding: utf-8 -*-

from __future__ import unicode_literals


__version__ = '2.2.1'


default_app_config = 'aldryn_newsblog.apps.AldrynNewsBlog'
